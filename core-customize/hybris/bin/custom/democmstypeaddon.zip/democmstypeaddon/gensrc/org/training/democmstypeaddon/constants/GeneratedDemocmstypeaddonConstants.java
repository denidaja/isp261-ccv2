/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at 20 Jul 2022, 01:16:00                       ---
 * ----------------------------------------------------------------
 */
package org.training.democmstypeaddon.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated(since = "ages", forRemoval = false)
@SuppressWarnings({"unused","cast"})
public class GeneratedDemocmstypeaddonConstants
{
	public static final String EXTENSIONNAME = "democmstypeaddon";
	
	protected GeneratedDemocmstypeaddonConstants()
	{
		// private constructor
	}
	
	
}
